<?= $this->include('template/admin_header'); ?>

<h2><?= $title; ?></h2>
<form action="" method="post" enctype="multipart/form-data">
    <p><input type="text" name="judul" class="judul" placeholder="Judul Artikel"></p>
    <p><textarea name="isi" cols="50" class="textarea" rows="10" placeholder="Isi Artikel"></textarea></p>
    <p>
        <input type="file" name="gambar" class="gambar">
    </p>
    <div>
        <button type="submit" value="Kirim" class="kirim">Kirim</button>
    </div>
</form>

<?= $this->include('template/admin_footer'); ?>